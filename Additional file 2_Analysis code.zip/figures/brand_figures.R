# Figure 2 and Supplementary Figure S1. Run Rscript brand_figures.R <output-dir> <existing-S1A.png>.
library(grid)
library(ragg)
library(png)
args <- commandArgs(trailingOnly=TRUE)
out <- args[1]
original <- args[2]
stopifnot(dir.exists(out),file.exists(original))
se <- c(19,8,13,6,7,19,23)
sn <- c(2390,1172,1378,829,1295,2390,2644)
te <- c(10,8,3,7,3,7,12)
tn <- c(6079,5567,4623,1295,4623,1456,2544)
v <- (se/(sn-se))/(te/(tn-te))
delta <- qnorm(.975)*sqrt(1/se+1/(sn-se)+1/te+1/(tn-te))
rows <- data.frame(label=c("Primary comparison","Sole indication: Weight control","Wegovy vs Zepbound","Ozempic vs Mounjaro","Mounjaro vs Zepbound","Zepbound excluded","Primary comparison"),se,sn,te,tn,ROR=v,lo=v*exp(-delta),hi=v*exp(delta))
write.csv(rows,file.path(out,"Figure2_data.csv"),row.names=FALSE)
label <- function(txt,x,y,size=8.8,bold=FALSE,align="left",col="black") {
 grid.text(txt,x=x,y=y,just=c(align,"centre"),gp=gpar(fontfamily=face_family,fontsize=size,fontface=if(bold) "bold" else "plain",col=col))
}
lin <- function(x1,y1,x2,y2,color="black",width=1,type=1) grid.lines(c(x1,x2),c(y1,y2),gp=gpar(col=color,lwd=width,lty=type,lineend="butt"))
headband <- function(txt,y,h=.056) {
 grid.rect(x=.5,y=y,width=.978,height=h,gp=gpar(fill="#eeeeee",col=NA))
 label(txt,.024,y,9.2,TRUE)
}
forest <- function(xx,yy,lo,hi,center,at,lower,upper,left,right,ybottom,ytop,axis_y,axis_label) {
 stopifnot(all(lo > 0),all(hi > 0),all(center > 0),lower > 0)
 tr <- function(x) left+(log2(x)-log2(lower))/(log2(upper)-log2(lower))*(right-left)
 lin(tr(1),ybottom,tr(1),ytop,"#5b5b5b",.9,"dashed")
 for(i in seq_along(xx)){
  y <- yy[i]; l<-tr(lo[i]); h<-tr(hi[i])
  lin(l,y,h,y);grid.segments(unit(c(l,h),"npc"),unit(y,"npc")-unit(1,"mm"),unit(c(l,h),"npc"),unit(y,"npc")+unit(1,"mm"),gp=gpar(lwd=1))
  grid.points(x=unit(tr(center[i]),"npc"),y=unit(y,"npc"),pch=xx[i],size=unit(2.2,"mm"),gp=gpar(col="black",fill="black"))
 }
 lin(tr(lower),axis_y,tr(upper),axis_y)
 for(a in at){lin(tr(a),axis_y,tr(a),axis_y-.011);label(a,tr(a),axis_y-.040,7.6,align="centre")}
 label(axis_label,(left+right)/2,axis_y-.093,8.2,align="centre")
}
draw_main <- function() {
 grid.newpage()
 label("Comparison",.024,.955,9.5,TRUE);label("ED / reports",.415,.955,8.7,TRUE,align="centre")
 label("ROR (95% CI)",.982,.955,9.4,TRUE,align="right")
 ys <- c(.817,.729,.566,.484,.402,.320,.158)
 headband("FAERS  |  Weight-management reports",.896)
 headband("FAERS  |  Post hoc product comparisons",.646)
 headband("EudraVigilance  |  Weight-management reports",.237)
 for(i in seq_len(nrow(rows))){
  label(rows$label[i],.024,ys[i],8.5)
  label(sprintf("%d/%s vs %d/%s",se[i],format(sn[i],big.mark=","),te[i],format(tn[i],big.mark=",")),.421,ys[i],7.7,align="centre")
  label(sprintf("%.2f (%.2f\u2013%.2f)",v[i],rows$lo[i],rows$hi[i]),.982,ys[i],8.4,align="right")
 }
 forest(rep(16,7),ys,rows$lo,rows$hi,v,c(.5,1,2,4,8,16,32,64),.375,64,.565,.793,.105,.85,.107,"Reporting odds ratio (log scale)")
}
draw_supp <- function() {
 grid.newpage()
 label("A   Age and recorded type 2 diabetes",.022,.981,10,TRUE)
 grid.raster(readPNG(original,native=TRUE),x=.5,y=.707,width=.989,height=unit(.989*7.2*3.653/6.6,"in"),interpolate=TRUE)
 label("B   Indication interaction and reporter adjustment",.022,.423,10,TRUE)
 label("Estimate (95% CI)",.980,.389,8.6,TRUE,align="right")
 headband("Weight management vs T2DM  |  Adjusted ratio of RORs",.355,.040)
 headband("Reporter adjustment  |  Same 2,636 reports, 27 with ED",.200,.040)
 ys<-c(.303,.250,.146,.092)
 for(i in seq_along(ys)){
  label(c("Full study period","January 2024 onward","Age and receipt quarter","Plus reporter occupation")[i],.026,ys[i],8.5)
  label(c("3.86 (1.09\u201313.66)","3.11 (0.77\u201312.59)","4.37 (1.84\u201310.38)","3.52 (1.46\u20138.49)")[i],.980,ys[i],8.6,align="right")
 }
 pushViewport(viewport(y=.05,height=.30,just="bottom"))
 yf<-(ys-.05)/.30
 forest(c(18,18,16,16),yf,c(1.09,.77,1.84,1.46),c(13.66,12.59,10.38,8.49),c(3.86,3.11,4.37,3.52),c(.5,1,2,4,8,16),.5,16,.51,.755,.0,1,.0,"Log scale")
 popViewport()
}
output <- function(name,h,fun) {
 svglite::svglite(file.path(out,paste0(name,".svg")),width=7.2,height=h);fun();dev.off()
 grDevices::cairo_pdf(file.path(out,paste0(name,".pdf")),width=7.2,height=h,family="Arial");fun();dev.off()
 for (typ in c("tiff","png")) {
  f<-file.path(out,paste0(name,".",typ))
  if(typ=="tiff") agg_tiff(f,width=7.2,height=h,units="in",res=600,compression="lzw",background="white")
  else agg_png(f,width=7.2,height=h,units="in",res=600,background="white")
  fun();dev.off()
 }
}
face_family <- "Arial"
output("Figure 2",5.1,draw_main)
face_family <- "Times New Roman"
output("Figure S1",7.75,draw_supp)
