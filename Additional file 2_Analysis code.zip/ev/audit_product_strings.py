"""List all qualifying raw tirzepatide product strings in the final EV weight-management cohort.
Run after ev/analyse_ev.py. Outputs contain aggregate counts, never report identifiers.
"""
from pathlib import Path
import csv
import os
import re
from collections import defaultdict
from openpyxl import load_workbook

root = Path(__file__).resolve().parent
manifest = root / 'source_manifest.csv'
cohort = root / 'master_cases.csv'
terms = {'obesity','central obesity','sarcopenic obesity','overweight','weight control','weight management','body mass index increased','weight loss poor'}
role = re.compile(r'\(([SI])\s+-\s+(.+?)\s+-\s+')
target = re.compile(r'tirzepatide|mounjaro|zepbound', re.I)
with cohort.open(encoding='utf-8-sig') as stream:
    wanted = {row['key']: row['case_id'] for row in csv.DictReader(stream) if row['drug']=='tirzepatide'}
with manifest.open(encoding='utf-8-sig') as stream:
    files = [Path(row['path']) for row in csv.DictReader(stream)]
products = defaultdict(set)
for path in files:
    if path.parent.name.lower() not in {'tirzepatide','替尔'}:
        continue
    workbook = load_workbook(path,read_only=True,data_only=True)
    rows = iter(workbook.active.values)
    for _ in range(4):
        next(rows)
    number = 0
    selected = False
    for row in rows:
        if row[0]:
            number += 1
            key = f'tirz_{path.stem}_{number}'
            selected = key in wanted
            if selected:
                assert str(row[0]).strip().upper()==wanted[key]
        if selected and row[11]:
            entry = str(row[11])
            m = role.search(entry)
            if m:
                name = ' '.join(entry[:m.start()].upper().split())
                indications = {' '.join(t.lower().split()) for t in m[2].split(',')}
                if target.search(name) and terms & indications:
                    products[name].add(key)
    workbook.close()
assert set.union(*products.values())==set(wanted)
with (root/'qualifying_tirzepatide_product_strings.csv').open('w',encoding='utf8',newline='') as out:
    writer=csv.writer(out)
    writer.writerow(['qualifying_product_text','reports_with_text'])
    writer.writerows((name,len(keys)) for name,keys in sorted(products.items()))
print('Eligible reports:',len(wanted))
for name,keys in sorted(products.items()):
    print(name,len(keys))
