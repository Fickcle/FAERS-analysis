from pathlib import Path
from datetime import date,datetime,timedelta
from collections import Counter
import hashlib, re, sys
import pandas as pd
from openpyxl import load_workbook
import os
from scipy.stats import false_discovery_control
import numpy as np
OUT=Path(__file__).resolve().parent
ROOT=OUT.parent
FA=ROOT/'faers'
sys.path.insert(0,str(FA))
from analyse import compare
from rebuild import DICT, WM, DM, STRICT
TERM=re.compile(r'(?:^|[,;|\r\n])\s*('+'|'.join(re.escape(s).replace(r'\ ',r'\s+') for s in DICT.pt_key)+r')\s*(?=[(\[,;|\r\n]|$)',re.I)
ROLE=re.compile(r'\(([SI])\s+-\s+(.+?)\s+-\s+')
DRUGS={'semaglutide':('司美','sema',re.compile('semaglutide|ozempic|wegovy|rybelsus',re.I)),'tirzepatide':('替尔','tirz',re.compile('tirzepatide|mounjaro|zepbound',re.I))}
def save(rows,name):pd.DataFrame(rows).to_csv(OUT/(name+'.csv'),index=False,encoding='utf-8-sig')
def dateof(v):
    if isinstance(v,datetime):return v.date()
    if isinstance(v,date):return v
    if isinstance(v,(float,int)):return date(1899,12,30)+timedelta(days=int(v))
    return date.fromisoformat(str(v)[:10])
def raw():
    rows=[];manifest=[]
    for drug,(folder,tag,pat) in DRUGS.items():
        for yr in range(2022,2027):
            raw_root=Path(os.getenv("EV_RAW_DIR",ROOT/'inputs'/'ev'))
            p=raw_root/drug/f'{yr}.xlsx'
            if not p.exists():p=raw_root/folder/f'{yr}.xlsx' 
            w=load_workbook(p,read_only=True,data_only=True); it=iter(w.active.values)
            next(it);run=next(it)[0];next(it);h=next(it)
            assert h[0]=='EU Local Number' and h[1]=='EV Gateway Receipt Date' and 'Reaction List PT' in h[10] and 'Suspect/interacting' in h[11]
            ids=set();curr=None;dates=[]
            for row in it:
                if row[0]:
                    cid=str(row[0]).strip().upper();assert cid not in ids;ids.add(cid)
                    dt=dateof(row[1]).isoformat();dates.append(dt)
                    curr=dict(case_id=cid,key=f'{tag}_{yr}_{len(ids)}',drug=drug,year=yr,received=dt,age_group=row[6],sex=row[8],reporter=row[3] or 'Missing',geog=row[4],terms=set(),suspect=set(),roles=set(),pts=set(),wm_brands=set());rows.append(curr)
                elif row[1] or row[8]:raise ValueError('unlinked demographics')
                if not curr:continue
                if row[10]:
                    curr['pts'].update(' '.join(m.group(1).lower().split()) for m in TERM.finditer(str(row[10])))
                if row[11]:
                    t=str(row[11]);m=ROLE.search(t)
                    if m and pat.search(t[:m.start()]):
                        terms={' '.join(x.lower().split()) for x in m[2].split(',')}
                        if terms & WM:
                            rawname=t[:m.start()].upper()
                            curr['wm_brands'].update(name for name in ('MOUNJARO','ZEPBOUND') if name in rawname)
                        curr['terms'].update(terms);curr['roles'].add(m[1])
                        if m[1]=='S':curr['suspect'].update(terms)
            w.close()
            manifest.append(dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),run=run,min_date=min(dates),max_date=max(dates),case_blocks=len(ids),Q3=sum('2026-07-01'<=d<='2026-09-30' for d in dates)))
            print(tag,yr,len(ids),flush=True)
    save(manifest,'source_manifest')
    for r in rows:
        r.update(wm=bool(r['terms']&WM),dm=bool(r['terms']&DM),obesity='obesity' in r['terms'],strict5=bool(r['terms']&STRICT),target_suspect_wm=bool(r['suspect']&WM),ed='erectile dysfunction' in r['pts'],adult=r['age_group'] in ('18-64 Years','65-85 Years','More than 85 Years'),region={'European Economic Area':'EEA','Non European Economic Area':'non-EEA'}.get(r['geog'],'Missing'))
        for k in ['pts','roles','terms','suspect','wm_brands']:r[k]='|'.join(sorted(r[k]))
    return pd.DataFrame(rows)
def run():
    rawdata=raw()
    prev_ids=set(rawdata.loc[rawdata.received<='2026-06-30','case_id'])
    flows=[];screens=[];sens=[];groups=[];windows=[];bases={};overlaps={}
    for k,end in [('june','2026-06-30'),('sept','2026-09-30')]:
        v=rawdata[rawdata.received.between('2022-04-01',end)].sort_values(['received','year','key'],ascending=[False,False,True])
        latest=v.drop_duplicates(['case_id','drug'])
        male=latest[latest.sex=='Male']
        shared=male[male.case_id.duplicated(keep=False)]
        overlaps[k]=set(shared.case_id)
        d=male[~male.case_id.isin(shared.case_id)].copy()
        assert d.case_id.is_unique and d.roles.ne('').all()
        d['quarter']=pd.to_datetime(d.received).dt.to_period('Q').astype(str)
        d['q3_first_observed']=~d.case_id.isin(prev_ids)&d.received.between('2026-07-01','2026-09-30')
        for stage,f in [('window blocks',v),('latest',latest),('male',male),('shared excluded',shared),('exclusive male',d),('adult male',d[d.adult]),('adult male WM',d[d.adult&d.wm])]:
            for drug,g in f.groupby('drug'):flows.append(dict(snapshot=k,stage=stage,drug=drug,reports=len(g),ED=int(g.ed.sum())))
        save(d,k+'_male_case_frame')
        w=d[d.adult&d.wm];bases[k]=w
        windows.append(dict(window=k,**compare(w)))
        if k=='sept':
            windows.append(dict(window='Q3 first observed in supplied files',**compare(w[w.q3_first_observed])))
            save(w,'master_cases')
            cohort=w[w.drug=='tirzepatide']
            save([{'product':label,'reports':int(mask.sum()),'ED':int(cohort.loc[mask,'ed'].sum())} for label,mask in [('Mounjaro named',cohort.wm_brands.str.contains('MOUNJARO')),('Zepbound named',cohort.wm_brands.str.contains('ZEPBOUND')),('Unnamed brand',cohort.wm_brands.eq(''))]],'brand_composition')
        for name,mask in [('no T2DM',~w.dm),('five terms',w.strict5),('exact Obesity',w.obesity),('Suspect only',w.target_suspect_wm),('2024Q1 onward',w.received>='2024-01-01')]:sens.append(dict(snapshot=k,analysis=name,**compare(w[mask])))
        for col in ['reporter','region','age_group']:
            for val,g in w.groupby(col):groups.append(dict(snapshot=k,variable=col,level=val,**compare(g)))
        for label,g in [('WM only',d[d.adult&d.wm&~d.dm]),('T2DM only',d[d.adult&~d.wm&d.dm]),('both',d[d.adult&d.wm&d.dm]),('neither',d[d.adult&~d.wm&~d.dm])]:
            groups.append(dict(snapshot=k,variable='indication',level=label,**compare(g)))
        tests=[dict(snapshot=k,PT=t.pt_original,**compare(w,w.pts.map(lambda s:t.pt_key in s.split('|')))) for t in DICT.itertuples()]
        for r,q in zip(tests,false_discovery_control([a['fisher_p'] for a in tests])):r['BH_q']=q
        screens.extend(tests)
        if k=='june':
            assert len(overlaps[k])==153
    for data,name in [(flows,'flow'),(windows,'window_comparison'),(sens,'sensitivity'),(groups,'subgroups'),(screens,'fdr_39')]:save(data,name)
    june,sept=bases.values(); ids=set(june.case_id); new=sept[~sept.case_id.isin(ids)]
    reconciliation=[]
    for label,f in [('retained',sept[sept.case_id.isin(ids)]),('left cohort',june[~june.case_id.isin(sept.case_id)]),('entered; Q3 first observed',new[new.q3_first_observed]),('entered; earlier record',new[~new.q3_first_observed])]:
        for drug in DRUGS:
            g=f[f.drug==drug]; reconciliation.append(dict(change=label,drug=drug,n=len(g),ED=g.ed.sum()))
    save(reconciliation,'cohort_changes')
    print(pd.DataFrame(windows).to_string(index=False),flush=True)
if __name__=='__main__':run()

