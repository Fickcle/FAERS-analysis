if (.Platform$OS.type=="windows") invisible(Sys.setlocale("LC_ALL","English_United States.utf8"))
library(survival)
filearg <- sub("^--file=","",grep("^--file=",commandArgs(),value=TRUE)[1])
root <- dirname(normalizePath(filearg))
source(file.path(dirname(root),"faers","indication_model.R"))
inter <- list(); adjusted <- list()
for (k in c("june","sept")) {
  d <- read.csv(file.path(root,paste0(k,"_male_case_frame.csv")),colClasses="character",na.strings=character(),fileEncoding="UTF-8-BOM")
  d <- subset(d,adult=="True"); d$event <- as.integer(d$ed=="True"); d$drug <- as.integer(d$drug=="semaglutide")
  wm <- d$wm=="True"; dm <- d$dm=="True"
  d$group <- ifelse(wm & !dm,"WM",ifelse(!wm & dm,"T2DM","other"))
  x <- d[d$group!="other",]
  for (period in c("Full","Common")) {
    m <- if(period=="Full") x else subset(x,quarter>="2024Q1")
    for (adj in c(FALSE,TRUE)) {
      inter[[length(inter)+1]] <- cbind(snapshot=k,period,adjusted=adj,fitone(m,adj))
    }
  }
  w <- d[wm,]
  for (label in c("age","quarter","age and quarter","reporter","region")) {
    w$stratum <- switch(label,age=w$age_group,quarter=w$quarter,"age and quarter"=interaction(w$age_group,w$quarter,drop=TRUE),reporter=w$reporter,region=w$region)
    keep <- vapply(split(seq_len(nrow(w)),w$stratum),function(i) length(unique(w$event[i]))==2 && length(unique(w$drug[i]))==2,logical(1))
    a <- w[as.character(w$stratum) %in% names(keep)[keep],]
    fit <- clogit(event~drug+strata(stratum),data=a,method="exact")
    beta <- unname(coef(fit)[1]);se <- sqrt(vcov(fit)[1,1])
    adjusted[[length(adjusted)+1]] <- data.frame(snapshot=k,adjustment=label,n=nrow(a),events=sum(a$event),estimate=exp(beta),lower=exp(beta-qnorm(.975)*se),upper=exp(beta+qnorm(.975)*se),p=2*pnorm(-abs(beta/se)))
  }
}
z <- do.call(rbind,inter)
write.csv(z,file.path(root,"indication_interaction.csv"),row.names=FALSE)
write.csv(do.call(rbind,adjusted),file.path(root,"stratified_models.csv"),row.names=FALSE)
print(subset(z,snapshot=="sept" & adjusted & group=="Interaction"))

