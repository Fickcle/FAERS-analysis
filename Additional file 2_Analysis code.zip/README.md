# Analysis code for the two reporting databases

Unzip into a writable directory. Python requires pandas, numpy, scipy (with false_discovery_control) and openpyxl. Conditional models use R 4.5.2 with survival. Run commands from the extracted directory. Each database is analysed separately. Case identifiers and raw data are not included.

Place the 18 FDA quarterly ASCII ZIP archives in inputs/faers/ as faers_ascii_2022q2.zip through faers_ascii_2026q3.zip. Place the saved EudraVigilance line listings in inputs/ev/semaglutide/ and inputs/ev/tirzepatide/ with filenames 2022.xlsx through 2026.xlsx. The exports must have the original English line-listing structure and report blocks. Public portal contents can change. Optional FAERS_ARCHIVE_MANIFEST points to a chronological CSV of absolute file paths in a column called file. EV_RAW_DIR can point to an alternative export directory.

Run in this order:

    python faers/rebuild.py
    python faers/analyse.py
    Rscript faers/models.R
    python ev/analyse_ev.py
    Rscript ev/models_ev.R
    Rscript fixed_sample.R
    python check_ed_definition.py faers/master_cases.csv ev/master_cases.csv
    python product_checks.py --inputs faers --out product_results

The core tables are written next to their database scripts. product_results must be a fresh output location. The within-tirzepatide estimate in Table 3 uses disjoint named products, report-level ED counts, an unadjusted log-Wald interval and a two-sided Fisher exact test. It is post hoc, with a nominal P value. ev/brand_composition.csv counts any qualifying entry explicitly naming the brand. These counts differ by design from the strict FAERS rule requiring consistent naming on all qualifying rows. Product text and healthcare-reporting patterns do not establish clinical incidence.

The package covers cohort assembly, drug and indication definitions, adverse-event screening, core statistical comparisons and named-product checks. Supplementary case review and publication artwork are described or presented in Additional file 1.

Input SHA-256 fingerprints are listed in input_checksums.csv. The names are the expected relative locations used by the scripts. Compare the fingerprints to verify the study downloads. Python 3.11 or later is required for hashlib.file_digest.

To render Figure 2 and Supplementary Figure S1, run Rscript figures/brand_figures.R <existing-output-directory> figures/S1A.png (R packages grid, ragg, png, svglite). Figure2_data.csv contains the seven aggregate comparisons. The S1A input is the published-layout subgroup panel.

After EV cohort assembly, run python ev/audit_product_strings.py to enumerate all distinct qualifying tirzepatide product strings from the original exports. A report may have multiple entries. Row counts in the string-level output can overlap.
