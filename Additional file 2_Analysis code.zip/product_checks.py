"""Recompute the post hoc product analyses from the September FAERS case frame and the 18 quarterly ZIP archives in source_manifest.csv.
Usage: python reproduce_product_checks.py --inputs <directory containing sept_male_case_frame.csv and source_manifest.csv> --out <new analysis directory>
Requirements: Python 3, NumPy and SciPy. Manifest file paths must point to the original archives.
"""
import argparse,csv,zipfile,re,json,math
from pathlib import Path
from collections import Counter,defaultdict
cli=argparse.ArgumentParser(description=__doc__)
cli.add_argument('--inputs',required=True,type=Path)
cli.add_argument('--out',required=True,type=Path)
args=cli.parse_args()
root=args.out
root.mkdir(parents=True,exist_ok=True)
def read(file):
 with (args.inputs/file).open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))
frame=read('sept_male_case_frame.csv')
adult=[r for r in frame if r['age_group']!='excluded']
drugs=['semaglutide','tirzepatide']
wm={'obesity','central obesity','sarcopenic obesity','overweight','weight control','weight management','body mass index increased','weight loss poor'}
def yes(r,k):return r[k]=='True'
def member(z,k):return next(n for n in z.namelist() if re.search(k+r'\d{2}q\d\.txt$',n,re.I))
brands=['WEGOVY','OZEMPIC','RYBELSUS','ZEPBOUND','MOUNJARO']
patterns=[re.compile(r'(?<![A-Z0-9])(?:'+x+r')(?![A-Z0-9])') for x in ['SEMAGLUTIDE|WEGOVY|OZEMPIC|RYBELSUS','TIRZEPATIDE|MOUNJARO|ZEPBOUND']]
main=[r for r in adult if yes(r,'wm') or yes(r,'dm')]
dm={'type 2 diabetes mellitus','insulin-requiring type 2 diabetes mellitus'}
for mf in read('source_manifest.csv'):
 grp={r['record_id'].encode():r for r in main if r['source_quarter']==mf['quarter']};seq=defaultdict(set);entries=defaultdict(list);reactions=defaultdict(set)
 with zipfile.ZipFile(args.inputs / mf['file']) as z:
  for k in ['INDI','DRUG','REAC']:
   with z.open(member(z,k)) as f:
    h=f.readline().decode().strip().lower().split('$')
    for line in f:
     pid=line.partition(b'$')[0]
     if pid not in grp:continue
     r=dict(zip(h,line.decode('latin1').rstrip('\r\n').split('$')))
     if k=='INDI':
      if ' '.join(r['indi_pt'].lower().split()) in (wm if yes(grp[pid],'wm') else dm):seq[pid].add(int(r['indi_drug_seq']))
     elif k=='REAC':reactions[pid].add(r['pt'].lower().strip())
     elif r['role_cod']=='PS' and patterns[drugs.index(grp[pid]['drug'])].search((r['drugname']+' '+r['prod_ai']).upper()) and int(r['drug_seq']) in seq[pid]:entries[pid].append(r['drugname'].upper())
 for pid,row in grp.items():
  names=entries[pid];assert names
  row['ptlist']=sorted(reactions[pid]);assert ('erectile dysfunction' in reactions[pid])==yes(row,'ed')
  hits=[{b for b in brands if re.search(r'\b'+b+r'\b',n)} for n in names]
  row['brand']=next(iter(hits[0])) if len(hits[0])==1 and all(x==hits[0] for x in hits) else 'unresolved'
  row['compound']=any('COMPOUND' in n for n in names)
 print(mf['quarter'],flush=True)

from scipy.stats import norm,fisher_exact
from scipy.special import gammaln,logsumexp
from scipy.optimize import brentq
import numpy as np

rs=main;wm=[r for r in rs if r['wm']=='True']; assert len(wm)==8469
def subset(rows,names):return [r for r in rows if r['brand'] in names and not r['compound']]
families=[['WEGOVY','ZEPBOUND'],['OZEMPIC','MOUNJARO']]
def calc(rows):
 vals=[]
 for drug in ['semaglutide','tirzepatide']:
  group=[r for r in rows if r['drug']==drug]; vals.extend([sum(r['ed']=='True' for r in group),len(group)])
 a,n,c,m=vals
 if not n or not m or not a+c:return vals+[None]*4
 v=np.array([a,n-a,c,m-c],float);v+=.5 if min(v)==0 else 0;b=math.log(v[0]*v[3]/(v[1]*v[2]));se=sum(1/v)**.5
 return vals+[math.exp(b),math.exp(b-1.95996398454*se),math.exp(b+1.95996398454*se),fisher_exact([[a,n-a],[c,m-c]]).pvalue]
def cond(rows,extra):
 groups=defaultdict(list)
 for r in rows:
  key=tuple(r[k] for k in extra);groups[key].append(r)
 L=[]
 for g in groups.values():
  a,n,c,m=calc(g)[:4];k=a+c
  if not(n*m and k and n+m>k):continue
  x=np.arange(max(0,k-m),min(n,k)+1,dtype=float)
  logw=-gammaln(x+1)-gammaln(n-x+1)-gammaln(k-x+1)-gammaln(m-k+x+1)
  L.append((a,x,logw,n+m,k))
 def ev(b):
  sc=info=0
  for a,x,w,_,_ in L:
   pr=np.exp(w+b*x-logsumexp(w+b*x));mean=pr@x;sc+=a-mean;info+=pr@((x-mean)**2)
  return sc,info
 if not L or not ev(-30)[0]>1e-7 or not ev(30)[0]<-1e-7:return None
 b=brentq(lambda v:ev(v)[0],-30,30);return [b,ev(b)[1]**-.5,sum(x[3] for x in L),sum(x[4] for x in L)]
def rr(b,se):return [math.exp(b),math.exp(b-1.95996398454*se),math.exp(b+1.95996398454*se),2*norm.sf(abs(b/se))]
result={}
for r in rs:r['fam']=next((str(i) for i,f in enumerate(families) if r['brand'] in f),'other')
for name,frame,keys in [('Original',rs,['age_group','quarter']),('Named only',subset(rs,sum(families,[])),['age_group','quarter']),('Family strata',subset(rs,sum(families,[])),['age_group','quarter','fam']),('WZ',subset(rs,families[0]),['age_group','quarter']),('OM',subset(rs,families[1]),['age_group','quarter'])]:
 store=[]
 for w,d in [('True','False'),('False','True')]:
  g=[r for r in frame if r['wm']==w and r['dm']==d];store.append([calc(g),cond(g,keys)])
 m1,m2=[x[1] for x in store]
 result[name]=[store,rr(m1[0]-m2[0],math.hypot(m1[1],m2[1])) if m1 and m2 else None]
print('MODELS',result)
for date in ['full','2024']:
 g=[r for r in wm if date=='full' or r['quarter']>='2024Q1'];a,b=[calc(subset(g,f)) for f in families];cells=[v for s in [a,b] for v in [s[0],s[1]-s[0],s[2],s[3]-s[2]]];result['ratio'+date]=rr(math.log(a[4]/b[4]),sum(1/v for v in cells)**.5)
result['leave']=calc([r for r in wm if r['brand']!='ZEPBOUND'])
cc=Counter(x['brand'] for x in wm); print(cc);result['brands']={k:calc([r for r in wm if r['brand']==k])[:4] for k in cc}
def profile(g):
 t=[len(r['ptlist']) for r in g];return [len(g),sum(r['ed']=='True' for r in g),dict(Counter(r['reporter'] for r in g)),list(np.percentile(t,[25,50,75])),sum(t)/len(t),sum(x==1 for x in t)]
result['prof']={k:profile([r for r in wm if r['brand']==k]) for k in cc}
result['zfirst']=min(r['received'] for r in wm if r['brand']=='ZEPBOUND');result['z23']=Counter(r['quarter'] for r in wm if r['brand']=='ZEPBOUND' and r['quarter']<'2024Q1')

PANEL=['abdominal discomfort', 'abdominal distension', 'abdominal pain', 'abdominal pain upper', 'acute kidney injury', 'alanine aminotransferase increased', 'allodynia', 'alopecia', 'anxiety', 'appendicitis', 'appetite disorder', 'arthralgia', 'asthenia', 'atrial fibrillation', 'back pain', 'blood glucose decreased', 'blood glucose increased', 'blood pressure decreased', 'blood pressure increased', 'bowel movement irregularity', 'brain fog', 'burning sensation', 'cardiac arrest', 'cerebrovascular accident', 'chest discomfort', 'chest pain', 'chills', 'cholecystitis', 'cholelithiasis', 'colitis', 'constipation', 'cough', 'decreased appetite', 'deep vein thrombosis', 'dehydration', 'depressed mood', 'depression', 'diarrhoea', 'discomfort', 'dizziness', 'drug hypersensitivity', 'dry mouth', 'dysgeusia', 'dyspepsia', 'dysphagia', 'dyspnoea', 'erectile dysfunction', 'eructation', 'fall', 'fatigue', 'feeding disorder', 'flatulence', 'food craving', 'gait disturbance', 'gallbladder disorder', 'gastroenteritis viral', 'gastrointestinal disorder', 'gastrooesophageal reflux disease', 'gout', 'headache', 'heart rate increased', 'hunger', 'hyperhidrosis', 'hypersensitivity', 'hypertension', 'hypoaesthesia', 'hypoglycaemia', 'hypophagia', 'hypotension', 'ileus', 'impaired gastric emptying', 'increased appetite', 'influenza', 'injection site bruising', 'injection site coldness', 'injection site discharge', 'injection site discomfort', 'injection site erythema', 'injection site haemorrhage', 'injection site injury', 'injection site mass', 'injection site pain', 'injection site pruritus', 'injection site rash', 'injection site reaction', 'injection site swelling', 'injection site urticaria', 'injury associated with device', 'insomnia', 'intestinal obstruction', 'lethargy', 'lipase increased', 'loss of consciousness', 'malaise', 'muscle atrophy', 'muscle spasms', 'muscular weakness', 'myalgia', 'myocardial infarction', 'nasopharyngitis', 'nausea', 'nephrolithiasis', 'optic ischaemic neuropathy', 'pain', 'pain in extremity', 'pain of skin', 'palpitations', 'pancreatitis', 'pancreatitis acute', 'panic attack', 'paraesthesia', 'peripheral swelling', 'pruritus', 'pulmonary embolism', 'pyrexia', 'rash', 'retching', 'sensitive skin', 'sepsis', 'skin burning sensation', 'sleep disorder due to general medical condition, insomnia type', 'small intestinal obstruction', 'somnolence', 'suicidal ideation', 'syncope', 'tachycardia', 'taste disorder', 'tremor', 'urticaria', 'vertigo', 'vision blurred', 'visual impairment', 'vomiting', 'weight decreased', 'weight increased']

result['clinical_panel']=PANEL
keep=[r for r in wm if set(r['ptlist']).intersection(PANEL)]
result['clinical_restrictions']={k:calc(g) for k,g in [('All',keep),('No Zepbound',[r for r in keep if r['brand']!='ZEPBOUND']),('WZ',subset(keep,families[0])),('OM',subset(keep,families[1]))]}
result['eligible_2023Q4']=Counter(r['brand'] for r in wm if r['quarter']=='2023Q4')
mf=next(r for r in read('source_manifest.csv') if r['quarter']=='2023Q4')
ids=set()
with zipfile.ZipFile(args.inputs / mf['file']) as z, z.open(member(z,'DRUG')) as f:
 fields=f.readline().lower().strip().split(b'$')
 for line in f:
  if b'ZEPBOUND' in line.upper():
   row=dict(zip(fields,line.rstrip(b'\r\n').split(b'$')))
   if re.search(rb'\bZEPBOUND\b',row[b'drugname'].upper()):ids.add(row[b'primaryid'])
result['raw_2023Q4_primaryids_naming_zepbound_any_role']=len(ids)
# Table 3: first product Mounjaro, second product Zepbound.
counts = []
for product in ('MOUNJARO', 'ZEPBOUND'):
    cohort = subset(wm, [product])
    positive = sum(row['ed'] == 'True' for row in cohort)
    counts.append([positive, len(cohort) - positive])
(a,b),(c,d) = counts
log_odds = math.log(a*d/(b*c))
se = math.sqrt(1/a + 1/b + 1/c + 1/d)
z = norm.ppf(0.975)
result['Mounjaro_vs_Zepbound'] = dict(cells=counts, ROR=math.exp(log_odds), lower=math.exp(log_odds-z*se), upper=math.exp(log_odds+z*se), fisher_p=float(fisher_exact(counts,alternative='two-sided').pvalue))
result['sole_weight_control']=calc([r for r in wm if r['indications'].strip().lower()=='weight control'])
with (root/'product_checks.json').open('x',encoding='utf-8') as out:
 json.dump(result,out,indent=2,allow_nan=False)
