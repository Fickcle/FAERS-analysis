# Fixed-sample conditional logistic comparisons for supplementary Tables S5 and S8.
library(survival)
script <- sub("^--file=", "", grep("^--file=", commandArgs(), value=TRUE)[1])
root <- dirname(normalizePath(script))
fit_model <- function(data, variable, label) {
  data$stratum <- variable
  fit <- clogit(event ~ semaglutide + strata(stratum), data=data, method="exact")
  beta <- unname(coef(fit)[1])
  se <- sqrt(vcov(fit)[1,1])
  data.frame(model=label, reports=nrow(data), ED=sum(data$event), ROR=exp(beta),
             lower=exp(beta-qnorm(.975)*se), upper=exp(beta+qnorm(.975)*se),
             nominal_p=2*pnorm(-abs(beta/se)))
}
for (db in c("faers","ev")) {
  path <- file.path(root,db,"sept_male_case_frame.csv")
  d <- read.csv(path, colClasses="character", na.strings=character(), fileEncoding="UTF-8-BOM")
  adult <- if (db=="faers") d$age_group!="excluded" else d$adult=="True"
  d <- d[adult & d$wm=="True", ]
  d$event <- as.integer(d$ed=="True")
  d$semaglutide <- as.integer(d$drug=="semaglutide")
  d$source <- d$reporter
  if (db=="faers") d$source[d$reporter %in% c("MD","PH","OT")] <- "Documented HCP"
  d$aq <- interaction(d$age_group,d$quarter,drop=TRUE)
  d$joint <- interaction(d$aq,d$source,drop=TRUE)
  indices <- split(seq_len(nrow(d)),d$joint)
  informative <- vapply(indices,function(ix) length(unique(d$event[ix]))==2L &&
                          length(unique(d$semaglutide[ix]))==2L,logical(1))
  s <- d[as.character(d$joint) %in% names(indices)[informative], ]
  known <- s[if(db=="faers") s$source %in% c("Documented HCP","CN") else s$source!="Missing", ]
  result <- rbind(fit_model(s,s$aq,"Age and quarter, fixed reports"),
                  fit_model(s,s$joint,"Age, quarter and report source"),
                  fit_model(known,known$joint,"Joint strata, known source"))
  write.csv(result,file.path(root,db,"fixed_sample_models.csv"),row.names=FALSE)
  print(result)
}
# Mantel-Haenszel estimate and CI for Table 3. Retain unclassified ages separately.
d <- read.csv(file.path(root,"faers","sept_male_case_frame.csv"), colClasses="character",
              fileEncoding="UTF-8-BOM",na.strings=character())
age <- suppressWarnings(as.numeric(d$age_years))
d <- d[d$wm=="True" & (d$age_group!="excluded" | is.na(age)), ]
d$age_group[d$age_group=="excluded"] <- "Unknown"
cells <- table(factor(d$drug,levels=c("semaglutide","tirzepatide")),
               factor(d$ed,levels=c("True","False")), d$age_group)
m <- mantelhaen.test(cells,correct=FALSE)
write.csv(data.frame(ROR=unname(m$estimate),lower=m$conf.int[1],upper=m$conf.int[2]),
          file.path(root,"faers","age_MH.csv"),row.names=FALSE)
print(m)
