if (.Platform$OS.type=="windows") invisible(Sys.setlocale("LC_ALL","English_United States.utf8"))
library(survival)
arg <- commandArgs(trailingOnly=FALSE)
root <- dirname(normalizePath(sub("^--file=","",grep("^--file=",arg,value=TRUE)[1])))
source(file.path(root,"indication_model.R"))
adjust <- function(w, label, strata_value) {
  w$stratum <- factor(strata_value)
  keep <- vapply(split(seq_len(nrow(w)), w$stratum), function(i)
    length(unique(w$event[i]))==2 && length(unique(w$drug[i]))==2,logical(1))
  a <- w[as.character(w$stratum) %in% names(keep)[keep],]
  beta <- se <- NA_real_
  if (length(unique(a$drug[a$event==1]))==2) {
    fit <- clogit(event~drug+strata(stratum),data=a,method="exact")
    beta <- unname(coef(fit)[1]);se <- sqrt(vcov(fit)[1,1])
  }
  data.frame(adjustment=label,total=nrow(w),informative_n=nrow(a),events=sum(a$event),
             estimate=exp(beta),lower=exp(beta-qnorm(.975)*se),upper=exp(beta+qnorm(.975)*se),
             p=2*pnorm(-abs(beta/se)))
}
models <- interactions <- list()
for (k in c("june","sept")) {
  d <- read.csv(file.path(root,paste0(k,"_male_case_frame.csv")),colClasses="character",na.strings=character())
  d <- d[d$age_group!="excluded",]
  d$event <- as.integer(d$ed=="True")
  d$drug <- as.integer(d$drug=="semaglutide")
  wm <- d$wm=="True"; dm <- d$dm=="True"
  d$group <- ifelse(wm & !dm,"WM",ifelse(dm & !wm,"T2DM","other"))
  x <- d[d$group!="other",]
  for (period in c("Full","Common")) {
    part <- if (period=="Full") x else x[x$quarter>="2024Q1",]
    for (adj in c(FALSE,TRUE)) {
      interactions[[length(interactions)+1]] <- cbind(snapshot=k,period,adjusted=adj,fitone(part,adj))
    }
  }
  w <- d[wm,]
  # Keep HP separate as an unresolved original code. Retain missing as its own stratum.
  occ <- ifelse(w$reporter %in% c("MD","PH","OT"),"documented HCP",w$reporter)
  for (label in c("age","quarter","age and quarter","occupation","consumer and documented HCP only")) {
    if (label=="consumer and documented HCP only") {
      sel <- occ %in% c("CN","documented HCP")
      result <- adjust(w[sel,],label,occ[sel])
    } else {
      strat <- switch(label,age=w$age_group,quarter=w$quarter,
                      "age and quarter"=interaction(w$age_group,w$quarter,drop=TRUE),
                      occupation=occ)
      result <- adjust(w,label,strat)
    }
    models[[length(models)+1]] <- cbind(snapshot=k,result)
  }
}
model <- do.call(rbind,models); inter <- do.call(rbind,interactions)
stopifnot(abs(subset(model,snapshot=="june" & adjustment=="age and quarter")$estimate-6.40)<.01,
          abs(subset(inter,snapshot=="june" & period=="Full" & adjusted & group=="Interaction")$estimate-4.35)<.01)
write.csv(model,file.path(root,"stratified_models.csv"),row.names=FALSE)
write.csv(inter,file.path(root,"indication_interaction.csv"),row.names=FALSE)
writeLines(capture.output(sessionInfo()),file.path(root,"R_session.txt"))
print(subset(model,snapshot=="sept"))
print(subset(inter,snapshot=="sept" & adjusted & group=="Interaction"))

