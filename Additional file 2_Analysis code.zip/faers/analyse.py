from rebuild import OUT, ROOT, DICT, save
import math
import numpy as np
import pandas as pd
from scipy.stats import fisher_exact, false_discovery_control, norm
from scipy.stats.contingency import odds_ratio

def compare(df,event=None):
    e=df.ed if event is None else event
    s=df.drug.eq('semaglutide')
    a=int((s&e).sum());b=int((s&~e).sum())
    c=int((~s&e).sum());d=int((~s&~e).sum())
    row=dict(sema_ED=a,sema_total=a+b,tirz_ED=c,tirz_total=c+d)
    r=lo=hi=p=np.nan;method='undefined'
    if a+b and c+d:
        p=fisher_exact([[a,b],[c,d]]).pvalue
        if a+c and b+d:
            v=np.array([a,b,c,d],dtype=float)
            method='log-Wald'
            if min(v)==0:v+=0.5;method='0.5 correction; log-Wald'
            r=v[0]*v[3]/(v[1]*v[2]);delta=norm.ppf(.975)*np.sqrt(sum(1/v))
            lo,hi=r*np.exp([-delta,delta])
    return dict(**row,ROR=r,lower=lo,upper=hi,fisher_p=p,method=method)

def run():
    frames={k:pd.read_csv(OUT/(k+'_male_case_frame.csv'),keep_default_na=False,dtype={'received':str,'initial':str}) for k in ['june','sept']}
    june,sept=frames.values()
    stages=[]; windows=[]; sensitivities=[]; reporters=[]; sub=[]; fdr=[]; clinical=[]
    groups={k:d[d.age_group.ne('excluded')&d.wm].copy() for k,d in frames.items()}
    base,full=groups.values()
    assert list(compare(base).values())[:4]==[17,1951,8,5360]
    for label,d in [('2022Q2-2026Q2',base),('2026Q3 first reports',full[full.new_q3]),('2022Q2-2026Q3',full)]:
        windows.append(dict(window=label,**compare(d)))
    for r in windows:
        a,b=r['sema_ED'],r['sema_total']-r['sema_ED']
        c,d=r['tirz_ED'],r['tirz_total']-r['tirz_ED']
        if min(a+b,c+d,a+c,b+d)>0:
            ci=odds_ratio([[a,b],[c,d]],kind='conditional').confidence_interval()
            r.update(exact_lower=ci.low,exact_upper=ci.high)
    save(pd.DataFrame(windows),'window_comparison')
    for k,d in frames.items():
        adult=d.age_group.ne('excluded')
        for label,cut in [('male single PS',d),('male target WM',d[d.wm]),('WM adult',d[adult&d.wm]),('WM only',d[adult&d.wm&~d.dm]),('T2DM only',d[adult&~d.wm&d.dm]),('both',d[adult&d.wm&d.dm]),('neither',d[adult&~d.wm&~d.dm])]:
            stages.append(dict(snapshot=k,stage=label,**compare(cut)))
        w=groups[k]
        for label,cut in [('no T2DM',w[~w.dm]),('five terms',w[w.strict5]),('exact obesity',w[w.obesity]),('2024Q1 onward',w[w.quarter>='2024Q1']),('no other-role comparator',w[~w.other_role])]:
            sensitivities.append(dict(snapshot=k,analysis=label,**compare(cut)))
        for col in ['age_group','dm']:
            for lev,cut in w.groupby(col):sub.append(dict(snapshot=k,variable=col,level=lev,**compare(cut)))
        for code,cut in w.groupby('reporter'):reporters.append(dict(snapshot=k,reporter_code=code,**compare(cut)))
        for drug,cut in w.groupby('drug'):
            for status,cs in cut.groupby('ed'):
                for code in ['any','DE','LT','HO','DS','CA','RI','OT']:
                    n=sum(bool(x) if code=='any' else code in x.split('|') for x in cs.outcomes)
                    clinical.append(dict(snapshot=k,drug=drug,ed=status,outcome=code,count=n,total=len(cs)))
        tests=[]
        for pt in DICT.itertuples():
            event=w.pts.map(lambda x:pt.pt_key in x.split('|'))
            tests.append(dict(snapshot=k,PT=pt.pt_original,**compare(w,event)))
        qs=false_discovery_control([r['fisher_p'] for r in tests])
        for r,q in zip(tests,qs):r['BH_q']=q
        fdr.extend(tests)
    for name,data in [('case_flow',stages),('sensitivity',sensitivities),('subgroup',sub),('reporter',reporters),('clinical_outcomes',clinical),('fdr_39',fdr)]:save(pd.DataFrame(data),name)
    keep=['case_id','record_id','version','source_quarter','initial','drug','ed','new_q3']
    delta=base[keep].merge(full[keep],on='case_id',how='outer',suffixes=('_june','_sept'),indicator=True)
    def status(r):
        if r['_merge']=='left_only':return 'left cohort'
        if r['_merge']=='right_only':return 'entered first Q3' if r.new_q3_sept else 'entered earlier or undated first receipt'
        if r.record_id_june!=r.record_id_sept or r.source_quarter_june!=r.source_quarter_sept:return 'retained revised'
        return 'retained unchanged'
    delta['change']=delta.apply(status,axis=1)
    save(delta,'case_reconciliation')
    save(delta.groupby('change').size().rename('cases').reset_index(),'change_counts')
    save(full,'master_cases')
    print(pd.DataFrame(windows).to_string(index=False));print(delta.change.value_counts())
if __name__=='__main__':run()

