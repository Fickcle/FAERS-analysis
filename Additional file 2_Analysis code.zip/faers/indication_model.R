fitone <- function(data,adjust){
 rows <- lapply(c("WM","T2DM"),function(g){
  a <- subset(data,group==g)
  total <- nrow(a)
  if(adjust){
   a$stratum <- interaction(a$age_group,a$quarter,drop=TRUE)
   keep <- vapply(split(seq_len(nrow(a)),a$stratum),function(i) length(unique(a$event[i]))==2 && length(unique(a$drug[i]))==2,logical(1))
   a <- a[as.character(a$stratum) %in% names(keep)[keep],]
   fit <- clogit(event~drug+strata(stratum),data=a,method="exact")
   beta <- unname(coef(fit)[1]); se <- sqrt(vcov(fit)[1,1])
  }else{
   tab <- table(factor(a$drug,levels=c(1,0)),factor(a$event,levels=c(1,0)))
   stopifnot(all(tab>0))
   beta <- log(tab[1,1]*tab[2,2]/(tab[1,2]*tab[2,1])); se <- sqrt(sum(1/tab))
  }
  data.frame(group=g,total_n=total,n=nrow(a),events=sum(a$event),beta=beta,se=se)
 })
 tab <- do.call(rbind,rows)
 # Disjoint indication groups imply independent slopes. Their log difference
 # is the drug-by-indication interaction with group-specific baseline strata.
 res <- rbind(tab,data.frame(group="Interaction", total_n=sum(tab$total_n),n=sum(tab$n),events=sum(tab$events),beta=diff(rev(tab$beta)),se=sqrt(sum(tab$se^2))))
 res$estimate <- exp(res$beta); res$lower <- exp(res$beta-qnorm(.975)*res$se);res$upper <- exp(res$beta+qnorm(.975)*res$se)
 res$p <- 2*pnorm(-abs(res$beta/res$se))
 res
}

