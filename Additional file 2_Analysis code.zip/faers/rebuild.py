from pathlib import Path
from collections import defaultdict
import csv, hashlib, io, json, re, zipfile
import pandas as pd
import numpy as np

OUT=Path(__file__).resolve().parent
ROOT=OUT.parent
QUARTERS=[f'{2022+(k+1)//4}Q{(k+1)%4+1}' for k in range(18)]
import os
manifest = os.getenv("FAERS_ARCHIVE_MANIFEST")
if manifest:
    with open(manifest, encoding="utf-8-sig") as stream:
        FILES = [Path(row["file"]).resolve() for row in csv.DictReader(stream)]
else:
    FILES = [ROOT / "inputs" / "faers" / ("faers_ascii_" + quarter.lower() + ".zip") for quarter in QUARTERS]
assert len(FILES)==18 and all(q.lower() in p.name.lower() for q,p in zip(QUARTERS,FILES))
DICT=pd.read_csv(ROOT/'pt_dictionary.csv')
PT=set(DICT.pt_key)
assert len(PT)==39
WM={'obesity','central obesity','sarcopenic obesity','overweight','weight control','weight management','body mass index increased','weight loss poor'}
STRICT={'obesity','overweight','weight control','body mass index increased','weight loss poor'}
DM={'type 2 diabetes mellitus','insulin-requiring type 2 diabetes mellitus'}
PAT=[re.compile(rb'(?<![A-Z0-9])(?:SEMAGLUTIDE|OZEMPIC|WEGOVY|RYBELSUS)(?![A-Z0-9])'),re.compile(rb'(?<![A-Z0-9])(?:TIRZEPATIDE|MOUNJARO|ZEPBOUND)(?![A-Z0-9])')]
DRUG=['semaglutide','tirzepatide']

def member(z,k):
    items=[n for n in z.namelist() if re.fullmatch(k+r'\d{2}Q[1-4]\.txt',re.split(r'[/\\]',n)[-1],re.I)]
    assert len(items)==1,(z.filename,k,items)
    return items[0]

def selected(z,k,fields,**kwargs):
    with z.open(member(z,k)) as f:
        return pd.read_csv(f,sep='$',encoding='latin1',quoting=csv.QUOTE_NONE,usecols=fields,**kwargs)

def save(df,name):
    df.to_csv(OUT/(name+'.csv'),index=False,encoding='utf-8-sig')

def snapshot(allrows,deleted):
    allrows=allrows.sort_values(['caseid','caseversion','q'],kind='stable')
    same=allrows.duplicated(['caseid','caseversion'],False)
    assert not (allrows.loc[same].groupby(['caseid','caseversion']).primaryid.nunique()>1).any()
    win=allrows.drop_duplicates('caseid',keep='last')
    win=win[~win.caseid.isin(deleted)]
    assert win.primaryid.is_unique
    return win

def extract(z,q,wanted):
    # Keep only exact reports from the winning source quarter.
    ps=defaultdict(lambda:defaultdict(set)); allroles=defaultdict(set)
    hints=[b'SEMAGLUTIDE',b'OZEMPIC',b'WEGOVY',b'RYBELSUS',b'TIRZEPATIDE',b'MOUNJARO',b'ZEPBOUND']
    with z.open(member(z,'DRUG')) as f:
        h=f.readline().lower().strip().split(b'$')
        drug,ai,seq,role=[h.index(c) for c in (b'drugname',b'prod_ai',b'drug_seq',b'role_cod')]
        for line in f:
            pid=line.split(b'$',1)[0]
            if pid not in wanted: continue
            up=line.upper()
            if not any(hint in up for hint in hints):continue
            r=up.rstrip(b'\r\n').split(b'$')
            txt=r[drug]+b' '+r[ai]
            for i,rx in enumerate(PAT):
                if rx.search(txt):
                    allroles[pid].add(i)
                    if r[role].strip()==b'PS':ps[pid][i].add(int(r[seq]))
    one={p:next(iter(v)) for p,v in ps.items() if len(v)==1}
    terms=defaultdict(set); pts=defaultdict(set); outcomes=defaultdict(set)
    for kind,field in [('INDI','indi_pt'),('REAC','pt'),('OUTC','outc_cod')]:
        with z.open(member(z,kind)) as f:
            h=f.readline().decode().strip().lower().split('$')
            col=h.index(field)
            if kind=='INDI':seq=h.index('indi_drug_seq')
            for line in f:
                pid=line.split(b'$',1)[0]
                if pid not in one: continue
                r=line.rstrip(b'\r\n').split(b'$')
                v=' '.join(r[col].decode('latin1').lower().split())
                if kind=='INDI' and r[seq].strip().isdigit() and int(r[seq]) in ps[pid][one[pid]]:terms[pid].add(v)
                if kind=='REAC' and v in PT:pts[pid].add(v)
                if kind=='OUTC' and v:outcomes[pid].add(v.upper())
    cols=['caseid','primaryid','caseversion','sex','age','age_cod','occp_cod','fda_dt','init_fda_dt']
    demo=selected(z,'DEMO',cols,dtype=str,keep_default_na=False)
    rows=[]
    for d in demo.itertuples(index=False):
        pid=d.primaryid.encode()
        if pid not in one or d.sex.upper().strip()!='M':continue
        t=terms[pid];i=one[pid]
        try:age=float(d.age)*{'YR':1,'DEC':10,'MON':1/12,'WK':7/365.25,'DY':1/365.25,'HR':1/8766}[d.age_cod]
        except (ValueError,KeyError):age=float('nan')
        g='18-49' if 18<=age<50 else '50-64' if 50<=age<65 else '>=65' if 65<=age<=120 else 'excluded'
        rows.append(dict(case_id=int(d.caseid),record_id=int(d.primaryid),version=int(d.caseversion),source_quarter=QUARTERS[q],quarter=d.fda_dt[:4]+'Q'+str((int(d.fda_dt[4:6])-1)//3+1),initial=d.init_fda_dt,received=d.fda_dt,drug=DRUG[i],age_group=g,age_years=age,reporter=d.occp_cod.strip().upper() or 'Missing',wm=bool(t&WM),dm=bool(t&DM),strict5=bool(t&STRICT),obesity='obesity' in t,indications=' | '.join(sorted(t)),ed='erectile dysfunction' in pts[pid],pts='|'.join(sorted(pts[pid])),outcomes='|'.join(sorted(outcomes[pid])),other_role=(1-i) in allroles[pid]))
    return pd.DataFrame(rows)

def run():
    parts=[]; deleted=set(); manifest=[]
    for i,p in enumerate(FILES):
        with zipfile.ZipFile(p) as z:
            d=selected(z,'DEMO',['caseid','caseversion','primaryid'],dtype={'caseid':'int64','primaryid':'int64','caseversion':'int32'})
            d['q']=np.int8(i);parts.append(d)
            vals=z.read(member(z,'DELETE')).splitlines()
            bad=[v for v in vals if v.strip() and not v.strip().isdigit()]
            assert all(b'case' in v.lower() or b'delet' in v.lower() for v in bad),bad[:2]
            deleted.update(int(v) for v in vals if v.strip().isdigit())
            with p.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
            manifest.append(dict(quarter=QUARTERS[i],file=str(p),sha256=sha,demo_rows=len(d),cumulative_deleted=len(deleted)))
            if i==16:
                historical_ids=pd.Index(pd.concat(parts,ignore_index=True).caseid.unique())
                june=snapshot(pd.concat(parts,ignore_index=True),deleted)
    sept=snapshot(pd.concat(parts,ignore_index=True),deleted)
    save(pd.DataFrame(manifest),'source_manifest')
    for label,frame in [('june',june),('sept',sept)]:print(label,'all unique nondeleted',len(frame),flush=True)
    frames={'june':[],'sept':[]}
    for i,p in enumerate(FILES):
        ids={k:set(f.loc[f.q==i,'primaryid']) for k,f in [('june',june),('sept',sept)]}
        wanted={str(x).encode() for x in ids['june']|ids['sept']}
        with zipfile.ZipFile(p) as z:rows=extract(z,i,wanted)
        for k in frames:frames[k].append(rows[rows.record_id.isin(ids[k])])
        print('linked',QUARTERS[i],len(rows),flush=True)
    for k in frames:
        f=pd.concat(frames[k],ignore_index=True)
        assert f.case_id.is_unique and f.record_id.is_unique
        f['new_q3']=(~f.case_id.isin(historical_ids)) & f.initial.between('20260701','20260930') & f.source_quarter.eq('2026Q3')
        save(f,k+'_male_case_frame')
if __name__=='__main__':run()

