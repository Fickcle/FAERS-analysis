"""Check both ED definitions in the final adult male weight-management master tables.
Usage: python check_ed_definition.py FAERS_master_cases.csv EV_master_cases.csv
No case identifiers are written.
"""
import csv
import math
import sys
from collections import Counter
from pathlib import Path

terms = ('erectile dysfunction', 'organic erectile dysfunction')
expected = {'FAERS': [(2390, 19), (6079, 10)], 'EudraVigilance': [(2644, 23), (2544, 12)]}
drugs = ('semaglutide', 'tirzepatide')

def check(source, path):
    counts = {drug: Counter() for drug in drugs}
    seen = set()
    with Path(path).open(encoding='utf-8-sig', newline='') as fin:
        for row in csv.DictReader(fin):
            case = row['case_id'].strip()
            if not case or case in seen:
                raise ValueError(f'{source}: missing or duplicate case identifier')
            seen.add(case)
            pt = {x.strip().casefold() for x in row['pts'].split('|')}
            exact, organic = (term in pt for term in terms)
            if str(row['ed']).strip().lower() not in (str(int(exact)), str(exact).lower()):
                raise ValueError(f'{source}: ED flag disagrees with exact term')
            counts[row['drug']].update(n=1, exact=exact, organic=organic,
                                      both=exact and organic, either=exact or organic)
    print(source)
    for drug, target in zip(drugs, expected[source]):
        c = counts[drug]
        if (c['n'], c['exact']) != target:
            raise ValueError(f'{source}: baseline does not match manuscript')
        print(drug, dict(c))
    for outcome in ('exact', 'either'):
        x, y = (counts[drug] for drug in drugs)
        a, c = x[outcome], y[outcome]
        b, d = x['n'] - a, y['n'] - c
        ror = a*d/(b*c)
        delta = 1.96*math.sqrt(sum(1/n for n in (a,b,c,d)))
        print(outcome, 'ROR and 95% log-Wald CI:', *(f'{v:.2f}' for v in (ror,ror*math.exp(-delta),ror*math.exp(delta))))
    return counts

if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    for source, path in zip(expected, sys.argv[1:]):
        check(source, path)
